"""Scanners for AWS resources."""
